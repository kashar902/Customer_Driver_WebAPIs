namespace DataAccessLayer.GlobalAndCommon;

public static class GlobalVariables
{
    public static int Otp { get; set; }
}